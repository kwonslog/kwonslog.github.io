#####
# 학습된 어댑터(LoRA/QLoRA)를 전혀 로드하지 않고, 공개 원본 모델만 사용해 답변을 생성
#####

import argparse
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

def build_argparser():
    p = argparse.ArgumentParser()
    p.add_argument("--model", type=str, default="Qwen/Qwen2-0.5B-Instruct",
                   help="원본(base) 모델 이름 또는 로컬 경로")
    p.add_argument("--prompt", "-q", type=str, default="PEFT와 QLoRA 차이를 한 줄로 설명해줘.",
                   help="질문/프롬프트")
    p.add_argument("--use_4bit", action="store_true",
                   help="bitsandbytes 4bit 로드 시도(설치 실패 시 자동 폴백)")
    p.add_argument("--max_new_tokens", type=int, default=192)
    p.add_argument("--temperature", type=float, default=0.7)
    p.add_argument("--top_p", type=float, default=0.9)
    return p

def load_base_model(model_name: str, use_4bit: bool):
    tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    quant_config = None
    kwargs = {"torch_dtype": torch.float16, "device_map": "auto"}

    if use_4bit:
        try:
            from transformers import BitsAndBytesConfig
            quant_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.float16,  # Pascal(6.1) → fp16 권장
            )
            kwargs["quantization_config"] = quant_config
            print("[INFO] 4bit 로드 활성화(bitsandbytes).")
        except Exception as e:
            print(f"[WARN] bitsandbytes 4bit 비활성(이유: {e}). FP16/CPU로 폴백합니다.")

    model = AutoModelForCausalLM.from_pretrained(model_name, **kwargs)
    model.eval()
    return tokenizer, model

def chat_once(tokenizer, model, user_text: str, max_new_tokens: int, temperature: float, top_p: float):
    # Qwen2 채팅 템플릿 사용 → 입력 ids 생성
    messages = [{"role": "user", "content": user_text}]
    prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

    inputs = tokenizer(prompt, return_tensors="pt")
    # 디바이스로 이동
    device = next(model.parameters()).device
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=1.1,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    # 생성된 토큰만 디코딩(프롬프트 길이 이후)
    gen_ids = out[0, inputs["input_ids"].shape[1]:]
    text = tokenizer.decode(gen_ids, skip_special_tokens=True)
    return text.strip()

def main():
    args = build_argparser().parse_args()
    tokenizer, model = load_base_model(args.model, args.use_4bit)
    answer = chat_once(
        tokenizer, model, args.prompt,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
        top_p=args.top_p
    )
    print("\n=== Answer (base model only) ===\n")
    print(answer)

if __name__ == "__main__":
    main()
