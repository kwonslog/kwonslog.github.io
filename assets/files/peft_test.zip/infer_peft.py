#####
# 학습된 어댑터(LoRA/QLoRA)를 사용하여 답변을 생성
#####

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

# SFTTrainer가 저장한 폴더를 그대로 로드하면, base + adapter 결합 구성이 자동 처리됩니다.
ADAPTER_DIR = "out-qwen2-0p5b-lora"

tokenizer = AutoTokenizer.from_pretrained(ADAPTER_DIR, use_fast=True)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(
    ADAPTER_DIR,
    torch_dtype=torch.float16,
    device_map="auto"
)
model.eval()

def chat(user_text):
    messages = [
        {"role":"user","content":user_text}
    ]
    prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=192,
            do_sample=True,
            top_p=0.9,
            temperature=0.7,
            repetition_penalty=1.1
        )
    text = tokenizer.decode(out[0], skip_special_tokens=True)
    # 마지막 assistant 답변만 깔끔히 추출(간단 파서)
    sep = "assistant"
    return text.split(sep)[-1].strip()

if __name__ == "__main__":
    print(chat("RAG와 파인튜닝의 차이를 한 문단으로 설명해줘."))