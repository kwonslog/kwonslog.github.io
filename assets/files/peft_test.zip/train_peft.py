#####
# 추가 학습한 어댑터를 생성
#####

import os, argparse
import torch
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig,
    TrainingArguments
)
from peft import LoraConfig
from trl import SFTTrainer

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model", type=str, default="Qwen/Qwen2-0.5B-Instruct")
    p.add_argument("--data_path", type=str, default="mini_instruct.jsonl")
    p.add_argument("--output_dir", type=str, default="out-qwen2-0p5b-lora")
    p.add_argument("--cutoff_len", type=int, default=256)  # 4GB VRAM 안전 구간
    p.add_argument("--max_steps", type=int, default=100)   # 100 step ~ 10~30분 예상(환경차 큼)
    p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--per_device_train_batch_size", type=int, default=1)
    p.add_argument("--gradient_accumulation_steps", type=int, default=8)  # 유효 배치 8
    return p.parse_args()

def main():
    args = parse_args()
    os.environ["TOKENIZERS_PARALLELISM"] = "false"

    # 4bit 양자화(QLoRA) 설정
    quant_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16  # Pascal(6.1)에서는 bf16 대신 fp16 권장
    )

    tokenizer = AutoTokenizer.from_pretrained(args.model, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # 모델 로드 (자동 디바이스 매핑)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        quantization_config=quant_config,
        torch_dtype=torch.float16,
        device_map="auto",
    )

    # 데이터셋 로드(JSONL: messages list)
    ds = load_dataset("json", data_files=args.data_path, split="train")

    # chat 템플릿으로 프리렌더링(text 생성)
    def to_text(example):
        messages = example["messages"]
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=False
        )
        return {"text": text}

    ds = ds.map(to_text, remove_columns=ds.column_names)

    # LoRA 설정
    peft_cfg = LoraConfig(
        r=8, lora_alpha=16, lora_dropout=0.05,
        bias="none", task_type="CAUSAL_LM",
        target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"]
    )

    # 학습 세팅
    train_args = TrainingArguments(
        output_dir=args.output_dir,
        per_device_train_batch_size=args.per_device_train_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.lr,
        logging_steps=10,
        bf16=False,
        fp16=True,
        max_steps=args.max_steps,
        save_steps=args.max_steps,
        save_total_limit=1,
        optim="paged_adamw_8bit",   # bitsandbytes 옵티마이저
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        report_to="none",
    )

    # SFTTrainer 사용 (언어모델링 라벨 자동 생성)
    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        peft_config=peft_cfg,
        train_dataset=ds,
        dataset_text_field="text",
        max_seq_length=args.cutoff_len,
        packing=False,  # 예시 데이터가 짧아도 안전하게 off
        args=train_args,
    )

    trainer.train()
    trainer.save_model(args.output_dir)  # 어댑터+메타 저장
    tokenizer.save_pretrained(args.output_dir)

if __name__ == "__main__":
    main()
